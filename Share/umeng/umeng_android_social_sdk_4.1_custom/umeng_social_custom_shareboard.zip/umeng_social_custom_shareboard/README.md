友盟社会化组件自定义UI分享的简单示例
===========================

#步骤简述

> * 1、初始化UMSocialService；
> * 2、自定义UI；
> * 3、根据用户点击的平台，然后调用directShare或者postShare进行分享到该平台；    

## 示例图 :
![Alt text](http://img.blog.csdn.net/20140904115836734?watermark/2/text/aHR0cDovL2Jsb2cuY3Nkbi5uZXQvYmJveWZlaXl1/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70/gravity/Center width="400" height="640")
